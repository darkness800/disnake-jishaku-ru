# disnake-jishaku-ru
Русифицированный форк библиотеки "disnake-jishaku". (В стадии разработки)

Скачать в консоли:
```bash
pip install -U disnake-jishaku-ru
```

Документация:
https://jishaku.readthedocs.io/en/latest/
