# -*- coding: utf-8 -*-
# SPDX-License-Identifier: MIT

import typing

import disnake
from disnake.ext import commands

from jishaku.features.baseclass import Feature


class GuildFeature(Feature):
    """
    Feature containing the guild-related commands
    """

    @staticmethod
    def apply_overwrites(permissions: dict, allow: int, deny: int, name: str):
        """
        Applies overwrites to the permissions dictionary (see permtrace),
        based on an allow and deny mask.
        """

        allow: disnake.Permissions = disnake.Permissions(allow)
        deny: disnake.Permissions = disnake.Permissions(deny)

        # Denies first..
        for key, value in dict(deny).items():
            # Check that this is denied and it is not already denied
            # (we want to show the lowest-level reason for the denial)
            if value and permissions[key][0]:
                permissions[key] = (False, f"Это перезапись {name} канала")

        # Then allows
        for key, value in dict(allow).items():
            # Check that this is allowed and it is not already allowed
            # (we want to show the lowest-level reason for the allowance)
            if value and not permissions[key][0]:
                permissions[key] = (True, f"Это перезапись {name} канала")

    @staticmethod
    def chunks(array: list, chunk_size: int):
        """
        Chunks a list into chunks of a given size.
        Should probably be in utils, honestly.
        """
        for i in range(0, len(array), chunk_size):
            yield array[i:i + chunk_size]

    @Feature.Command(parent="jsk", name="permtrace")
    async def jsk_permtrace(
        self, ctx: commands.Context,
        channel: typing.Union[disnake.TextChannel, disnake.VoiceChannel],
        *targets: typing.Union[disnake.Member, disnake.Role]
    ):
        """
        Calculates the source of granted or rejected permissions.

        This accepts a channel, and either a member or a list of roles.
        It calculates permissions the same way Discord does, while keeping track of the source.
        """

        member_ids = {target.id: target for target in targets if isinstance(target, disnake.Member)}
        roles = []

        for target in targets:
            if isinstance(target, disnake.Member):
                roles.extend(list(target.roles))
            else:
                roles.append(target)

        # Remove duplicates
        roles = list(set(roles))

        # Dictionary to store the current permission state and reason
        # Stores <perm name>: (<perm allowed>, <reason>)
        permissions: typing.Dict[str, typing.Tuple[bool, str]] = {}

        if member_ids and channel.guild.owner_id in member_ids:
            # Is owner, has all perms
            for key in dict(disnake.Permissions.all()).keys():
                permissions[key] = (True, f"{channel.guild.owner.mention} Владеет сервером")
        else:
            # Otherwise, either not a member or not the guild owner, calculate perms manually
            is_administrator = False

            # Handle guild-level perms first
            for key, value in dict(channel.guild.default_role.permissions).items():
                permissions[key] = (value, "Это разрешение для всего сервера.")

            for role in roles:
                for key, value in dict(role.permissions).items():
                    # Roles can only ever allow permissions
                    # Denying a permission does nothing if a lower role allows it
                    if value and not permissions[key][0]:
                        permissions[key] = (value, f"это разрешение для всего сервера {role.name}")

                # Then administrator handling
                if role.permissions.administrator:
                    is_administrator = True

                    for key in dict(disnake.Permissions.all()).keys():
                        if not permissions[key][0]:
                            permissions[key] = (True, f"это разрешение предоставляется администратором на уровне всего сервера {role.name}")

            # If Administrator was granted, there is no reason to even do channel permissions
            if not is_administrator:
                # Now channel-level permissions

                # Special case for @everyone
                try:
                    maybe_everyone = channel._overwrites[0]
                    if maybe_everyone.id == channel.guild.default_role.id:
                        self.apply_overwrites(permissions, allow=maybe_everyone.allow, deny=maybe_everyone.deny, name="@everyone")
                        remaining_overwrites = channel._overwrites[1:]
                    else:
                        remaining_overwrites = channel._overwrites
                except IndexError:
                    remaining_overwrites = channel._overwrites

                role_lookup = {r.id: r for r in roles}

                # Denies are applied BEFORE allows, always
                # Handle denies
                for overwrite in remaining_overwrites:
                    if overwrite.type == 'role' and overwrite.id in role_lookup:
                        self.apply_overwrites(permissions, allow=0, deny=overwrite.deny, name=role_lookup[overwrite.id].name)

                # Handle allows
                for overwrite in remaining_overwrites:
                    if overwrite.type == 'role' and overwrite.id in role_lookup:
                        self.apply_overwrites(permissions, allow=overwrite.allow, deny=0, name=role_lookup[overwrite.id].name)

                if member_ids:
                    # Handle member-specific overwrites
                    for overwrite in remaining_overwrites:
                        if overwrite.type == 'member' and overwrite.id in member_ids:
                            self.apply_overwrites(permissions, allow=overwrite.allow, deny=overwrite.deny, name=f"{member_ids[overwrite.id].mention}")
                            break

        # Construct embed
        description = f"Это расчет разрешений для следующих целевых объектов в {channel.mention}:\n"
        description += "\n".join(f"- {target.mention}" for target in targets)

        description += (
            "\nПожалуйста, обратите внимание, что указанные причины являются ** наиболее фундаментальной ** причиной, по которой разрешение является таким, какое оно есть. "
            "Могут быть и другие причины, по которым эти разрешения сохраняются, даже если вы измените отображаемые данные."
        )

        embed = disnake.Embed(color=0x00FF00, description=description)

        allows = []
        denies = []

        for key, value in permissions.items():
            if value[0]:
                allows.append(f"\N{WHITE HEAVY CHECK MARK} {key} (because {value[1]})")
            else:
                denies.append(f"\N{CROSS MARK} {key} (because {value[1]})")

        for chunk in self.chunks(sorted(allows) + sorted(denies), 8):
            embed.add_field(name="...", value="\n".join(chunk), inline=False)

        await ctx.send(embed=embed)
